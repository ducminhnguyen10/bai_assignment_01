package com.example.demo.error;

public enum MessageType {
	SUCCESS, INFO, WARNING, ERROR
}
